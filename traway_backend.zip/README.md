# Ermin Traway API

Backend for Ermin Traway app

# Getting started

To get the Node server running locally:

- Clone this repo
- `npm install` to install all required dependencies
- `nodemon app` to start the local server
